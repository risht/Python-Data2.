'''
factorial 0 = 1
factorial 1 = 1 
factorial 2 = 2 * factorial 1 = 2 * 1 = 2
factorial 3 = 3 * factorial 2 = 3 * 2 * factorial 1 = 3 * 2 * 1 = 6
factorial 4 = 4 * factorial 3 = 4 * 3 * factorial 2 = 4 * 3 * 2 * factorial 1 = 4 * 3 * 2 * 1 = 24
factorial 5 = 5 * factorial 4 = 5 * 4 * factorial 3 = 5 * 4 * 3 * factorial 2 = 5 * 4 * 3 * 2 * factorial 1 = 5 * 4 * 3 * 2 * 1 = 120

factorial n = n * factorial (n-1)


'''

def factorial(n):
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)
    
    
n = int(input("Enter a number to find its factorial: "))
print(f"The factorial of {n} is {factorial(n)}")
# print(factorial(5)) # 120 
