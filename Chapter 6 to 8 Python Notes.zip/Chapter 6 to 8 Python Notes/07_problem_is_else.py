name = input("Enter the name : ")

if("Harry".lower() in name.lower()):
    print("this post is talking about harry")

else:
      print("this post is not talking about harry")

print("End of program")  