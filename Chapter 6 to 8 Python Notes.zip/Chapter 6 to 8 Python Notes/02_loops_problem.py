l = ["Harry", "Soham", "Sachin", "Rahul"]

for name in l:
    if name.startswith("S"):
        print(f"Hello {name}")  # prints all names starting with S
    else:
        print("Not found")  # prints Not found for all other names