names = ["rishabh", "sachin", "rohit","virat"] 

l1 = input("Enter the name : ")

if l1 in names: 
    print("name is present")

else:
    print("name is not present")
