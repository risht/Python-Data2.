def multiply(n):
    for i in range(1, 11):
     print(f"{n} * {i} = {n*i}")

n1 = int(input("Enter a number to print multiplication table: "))
multiply(n1)