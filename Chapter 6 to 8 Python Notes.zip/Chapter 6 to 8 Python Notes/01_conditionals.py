# if, else statements

a = int(input("Enter the age :"))

if a >=18:
    print("You are a adult.")
    print("Good for you")

else:
    print("You are an minor.")

print("End of program")