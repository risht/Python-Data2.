def greet():
    print("Good dAY")

# print is built in function
# range and len are built in functions


greet()