def inchtocm(inch):
    """Convert inches to centimeters."""
    return inch * 2.54

n = float(input("Enter length in inches: "))
print(f"{round(n, 2)} inches is equal to {round(inchtocm(n), 2)} centimeters")
