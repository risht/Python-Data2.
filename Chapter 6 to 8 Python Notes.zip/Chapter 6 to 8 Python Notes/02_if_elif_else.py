# if, else, elif in python

# IF,elif,else ladder

# If any one condition is true, it will execute the block of code and skip the rest of the conditions.

a = int(input("Enter the age : "))

if a >=18:
    print("You are a adult.")
    print("Good for you")

elif a <0:
    print("You are entering negative age.") 

elif a == 0:
    print("You are entering 0 age")

else:
    print("You are an minor.")

print("End of program")

