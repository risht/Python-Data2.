# while loop execute condition  is true
# while loop is used when we don't know how many times we want to execute the loop

# i = 1

# while i<51:
#     print(i)
#     i+=1
    #i = i + 1  

j = 0
while j<5:
    print("Harry")
    j=j+1