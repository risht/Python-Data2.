n = int(input("Enter a  number: "))

for i in range(2, n):
    if n%i == 0:
        print("number is not a prime number")
        break
else:
    print("number is a prime number")
# The else block of the for loop executes only if the loop is not terminated by a break statement.
