n = int(input("Enter a number: "))

j = 1
while j<5:
    print(f"{n} x {j} = {n * j}")
    j=j+1 