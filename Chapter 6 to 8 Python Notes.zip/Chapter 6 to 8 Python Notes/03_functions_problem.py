print("a",)
print("b",)
print("c",end="")
print("d",end="")

# to prevent the output from going to the next line, we can use the end parameter in the print function.
