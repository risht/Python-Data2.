#Function to convert Celsius to Fahrenheit

def fahrenheit_to_celsius(fahrenheit):
    """Convert Fahrenheit to Celsius."""
    return (fahrenheit - 32) * 5/9

f = float(input("Enter temperature in Celsius: "))
print(f"{round(f, 2)} Fahrenheit is equal to {round(fahrenheit_to_celsius(f), 2)} Celsius")


