def greet(name, ending="Thank you"): # function with arguments
    print(f"Good Day, {name}") # name is a parameter
    print(ending)    
    #return name + " " + ending # return is a keyword

greet("Rishabh","Thanks")

greet("Rohan")