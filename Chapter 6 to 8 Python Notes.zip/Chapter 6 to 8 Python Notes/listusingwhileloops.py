#Print elements of a list using while loop

k =[1,"sam",3.4,True]

i = 0

while i<len(k):
    print(k[i])
    i=i+1


