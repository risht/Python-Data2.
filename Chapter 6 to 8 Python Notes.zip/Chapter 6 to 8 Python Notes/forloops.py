for i in range(4):
    print(i)
# for loop is used when we know how many times we want to execute the loop
# ramge function is used to generate a sequence of numbers