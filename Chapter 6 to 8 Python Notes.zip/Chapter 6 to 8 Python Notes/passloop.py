for i in range(100):
    pass # passis a null statement, nothing happens when it executes, but you can use pass statement when a statement is required syntactically but you do not want any command or code to execute.


i = 0
while i <45:
    print(i)
    i = i + 1
