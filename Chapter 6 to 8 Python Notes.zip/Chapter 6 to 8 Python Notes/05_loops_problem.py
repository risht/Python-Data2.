n = int(input("Enter a number: "))

i = 1
sum = 0

while i<=n:
    sum = sum + i
    i = i + 1

print(sum) # sum of first n natural numbers
