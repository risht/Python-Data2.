# for i in range(100):
#   if i == 34:
#     break # break statement is used to exit the loop
#   print(i)



# for i in range(100):
#   if i == 34:
#     continue # comtinue statement is used to skip the current iteration and continue with the next iteration
#   print(i)



for i1 in range(4):
    print("printing")
    if i1 == 2: # if i is 2, the iteration is skipped 
        continue
    print(i1)  

#  Output:
# printing
# 0
# printing
# 1
# printing
# printing
# 3

