def numbers(a,b,c):
    if(a > b) and (a > c):
        return a
    elif (b > a) and (b > c):
        return b
    else:
        return c
    
n = int(input("Enter the first number:  "))
m = int(input("Enter the second number: "))
o = int(input("Enter the third number:  "))

print("The largest number is: ", numbers(n,m,o))

