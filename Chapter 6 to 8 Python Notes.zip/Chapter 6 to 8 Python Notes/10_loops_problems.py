n = int(input("Enter a number: "))

for i in range(1,11):
    print(f"{n} * {11-i} = {n*(11-i)}")