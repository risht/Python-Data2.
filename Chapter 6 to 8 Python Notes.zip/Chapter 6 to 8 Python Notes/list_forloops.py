# List
# l = [1,3,6,7,"hello",True,3.4,6,"world"]

# for i in (l):
#     print(i)

# tuples

t = (1,3,6,7,"hello",True,3.4,6,"world")
for i in (t):
    print(i)

# string
str = "HELLO WORLD"
for i in (str):
    print(i)    