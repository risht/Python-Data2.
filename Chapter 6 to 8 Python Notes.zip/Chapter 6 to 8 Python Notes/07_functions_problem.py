

def print_list(l,word):
    """Strip from the list."""
    n =[]
    for i in l:
        if not(i == word):
            n.append(i.strip(word))
    return n
        #  l.remove(word)
        #  return l

l = ["Roger","Rahul","Rohan","Shubham","an"]    

print(print_list(l,"an"))
    