n = float(input("Enter the marks of student : " ))


if(n <= 100 and n >= 90):
    print("Grade Ex")

elif(n < 90 and n >= 80):
    print("Grade A")

elif(n < 80 and n >= 70):
    print("Grade B")

elif(n < 70 and n >= 60):
    print("Grade C")

elif(n < 60 and n >= 50):
    print("Grade D")

elif(n < 50):
    print("Grade F")


print("End of program") 

