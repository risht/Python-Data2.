l= [1,7,8]
for item in l:
  print(item) # for loops got executed 3 times and then goes to else

else:
 print("done")
 