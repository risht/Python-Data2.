# Function Defination

def avg():
    n1= int(input("Enter the number  1 : "))
    n2 = int(input("Enter the number 2 : "))
    n3 = int(input("Enter the number 3 : "))

    average = (n1 + n2 + n3) / 3
    print("The average of the three numbers is : ", average)
    return average

# Function Calling
avg()
print("This is the end of the program")
avg()
print("This is the end of the program")
avg()
print("This is the end of the program")
avg()
avg()


