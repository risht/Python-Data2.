def greet(name, ending): # function with arguments
    print("Good Day" + " " + name) # name is a parameter
    print(ending)
    return name + " " + ending # return is a keyword
    # return "7"

# print is built in function
# range and len are built in functions


greet("Rishabh", "Have a nice day")

# a = greet("Rishabh", "Have a nice day")
#print(a)

# greet("Rohan", "Have a nice day")