subject1  = float(input("Enter the marks of subject 1: "))

subject2  = float(input("Enter the marks of subject 2: "))

subject3 = float(input("Enter the marks of subject 3: "))

# Check for total percentage

total_marks = subject1 + subject2 + subject3

total_percentage = (total_marks / 300) * 100

print("Total percentage is: ", total_percentage)


if(total_percentage >= 40 and subject1 >= 33 and subject2 >= 33 and subject3 >= 33):
    print("You are pass")

else:
    print("You are fail")
