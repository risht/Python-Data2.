a = int(input("Enter the age : "))

# Multiple if statements

# Statement 1

if a%2 == 0:
    print("a is even")

# 2 times if statements will be executed when a value is put 18 or greater than 18 then statement 1 and statement 2 will be executed of both if statements.

# Statement 2

if a >=18:
    print("You are a adult.")
    print("Good for you")

elif a <0:
    print("You are entering negative age.") 

elif a == 0:
    print("You are entering 0 age")

else:
    print("You are an minor.")

print("End of program")
