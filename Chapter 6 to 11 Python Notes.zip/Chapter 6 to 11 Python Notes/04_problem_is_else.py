n = input("Enter the username :" )


if len(n) < 10:
    print("Username contains less than 10 characters")

else:
    print("Username contain more than 10 characters")



