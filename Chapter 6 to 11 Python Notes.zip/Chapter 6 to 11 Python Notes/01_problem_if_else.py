a = int(input("Enter the number 1: "))

b = int(input("Enter the number 2: "))

c = int(input("Enter the number 3: "))

d  = int(input("Enter the number 4: "))

if(a>b and a>c and a>d):
    print("a is greatest")

elif(b>a and b>c and b>d):
    print("b is greatest")

elif(c>a and c>b and c>d):
    print("c is greatest")

elif(d>a and d>b and d>c):
    print("d is greatest")

else:
    print("All are equal")

print("End of program")
